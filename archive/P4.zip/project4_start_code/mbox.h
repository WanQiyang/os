#ifndef MBOX_H
#define MBOX_H

/* Includes definitions
 * for MAX_MBOXEN, MAX_MBOX_LENGTH,
 * and MAX_MESSAGE_LENGTH
 */
#include "common.h"

/* Perform any system-startup
 * initialization for the message
 * boxes.
 */
void init_mbox(void);

/* Opens the mailbox named 'name', or
 * creates a new message box if it
 * doesn't already exist.
 * A message box is a bounded buffer
 * which holds up to MAX_MBOX_LENGTH items.
 * If it fails because the message
 * box table is full, it will return -1.
 * Otherwise, it returns a message box
 * id.
 * You may assume that the name of the
 * message box is no longer than
 * MBOX_NAME_LENGTH.
 */
mbox_t do_mbox_open(const char *name);

/* Closes a message box
 */
void do_mbox_close(mbox_t mbox);

/* Determine if the given
 * message box is full.
 * Equivalently, determine
 * if sending to this mbox
 * would cause a process
 * to block.
 */
int do_mbox_is_full(mbox_t mbox);

/* Enqueues a message onto
 * a message box.  If the
 * message box is full, the
 * process will block until
 * it can add the item.
 * You may assume that the
 * message box ID has been
 * properly opened before this
 * call.
 * The message is 'nbytes' bytes
 * starting at offset 'msg'
 */
void do_mbox_send(mbox_t mbox, void *msg, int nbytes);

/* Receives a message from the
 * specified message box.  If
 * empty, the process will block
 * until it can remove an item.
 * You may assume that the
 * message box has been properly
 * opened before this call.
 * The message is copied into
 * 'msg'.  No more than
 * 'nbytes' bytes will by copied
 * into this buffer; longer
 * messages will be truncated.
 */
void do_mbox_recv(mbox_t mbox, void *msg, int nbytes);



#endif

