/* printf.h: Printing functions for debugging */
/* Do not change this file */

#ifndef PRINTF_H
#define PRINTF_H

void printf(int line, int col, char *format, ...);
static char msg1[] = "process1 is running";
static char msg2[] = "process1 is running";

#endif
