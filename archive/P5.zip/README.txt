说明：
tasks.c中选择PROC1和PROC2即为任务2测试程序，选择PROC3即为Bonus任务1测试程序；
memory.c中第13行定义CLOCK则采用表针算法，未定义则采用FIFO算法；
根据设计，打印的TLB Invalid Count即为缺页次数。
