/* printf.h: Printing functions for debugging */
/* Do not change this file */

#ifndef PRINTF_H
#define PRINTF_H

void printf(int line, int col, char *format, ...);

#endif
