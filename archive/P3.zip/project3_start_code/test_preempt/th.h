/* th.h Best viewed with tabs set to 4 spaces. */

#ifndef TH_H
#define TH_H

// Prototypes
void clock_thread(void);
void ps_thread(void);

#endif
