/* th.h Best viewed with tabs set to 4 spaces. */

#ifndef TH_H
#define TH_H

// Prototypes
void thread_1(void);
void thread_2(void);
void thread_3(void);
void thread_4(void);

#endif
