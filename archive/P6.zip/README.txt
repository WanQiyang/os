完成情况说明：
superblock测试部分：完成superblock备份，完成魔数检查，完成校验和检查；
文件系统接口测试部分：完成task1和task2的所有接口，未实现权限检查（但实现了chmod）；
fio部分：能够正常运行fio；
bonus部分：未开发SSD友好的文件系统。

由于SD卡空间不足，fio测试无法以任务书中的命令完成，须采用以下命令：
fio -iodepth 32 -thread -rw=write -ioengine=libaio -bs=128k -numjobs=10 -runtime=10 -name=test -directory=$(挂载点绝对路径) -size=300m
fio -iodepth 32 -thread -rw=randread -ioengine=libaio -bs=4k -numjobs=10 -runtime=10 -name=test -directory=$(挂载点绝对路径) -size=300m
